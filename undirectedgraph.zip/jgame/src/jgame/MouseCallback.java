/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jgame;

import java.awt.event.MouseEvent;

/**
 *
 * @author thmun
 */
public class MouseCallback {
    public void click(MouseEvent e) {}
    public void release(MouseEvent e) {}
    public void move(MouseEvent e) {}
}
